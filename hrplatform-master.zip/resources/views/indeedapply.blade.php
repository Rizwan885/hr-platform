<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>



    <span class="indeed-apply-widget" data-indeed-apply-apiToken="ae5b185bd5806dfa995e39cb355b687491b7563f84b2139ce4bab246121f089b" data-indeed-apply-email="5ee46b85355b24a2154c8ee4a9c2bb9228e35451752d44c4f55a628433fb88d3" data-indeed-apply-jobCompanyName="MAGCOD" data-indeed-apply-jobId="2" data-indeed-apply-jobLocation="Rawalpindi, Pakistan" data-indeed-apply-jobTitle="React JS Developer" data-indeed-apply-jobUrl="http://www.indeed.com">Apply</span>
    <script src="https://apply.indeed.com/indeedapply/static/scripts/app/bootstrap.js?hl=en&amp;co=US&amp;iip=1"></script>
    
</body>
</html>