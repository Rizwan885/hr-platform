<html>

    <form action="auth/google" method="get">
    <?php echo csrf_field(); ?>

<button>Login with google</button>
    
    </form>
</html><?php /**PATH F:\MAGCOD\hrplatform-master\resources\views/google.blade.php ENDPATH**/ ?>