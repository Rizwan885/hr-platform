<html>

    <a href="<?php echo e(route('admin_google')); ?>">Admin Login</a>
    <br><br><br>
    <a href="<?php echo e(route('emp_google')); ?>">Employeer Login</a>
    
    <br><br><br>
    
 
    <a href="<?php echo e(route('applicant_google')); ?>">Applicant Login</a>

    <br><br><br><br><br>


    

    
    

 
  <h4>Admin</h4>
    <form method="post" action="<?php echo e(route('admin_indeed')); ?>">
        <?php echo csrf_field(); ?>
      <input type="submit" value="login with indeed">
    </form>
    <br><br><br><br><br>
 

 
  <h4>Employeer</h4>
    <form method="post" action="<?php echo e(route('emp_indeed')); ?>">
        <?php echo csrf_field(); ?>
      <input type="submit" value="login with indeed">
    </form>
    <br><br><br><br><br>
    <hr>
 

<h1>Employeer Login with Linkedin</h1>


    <form method="post" action="<?php echo e(route('emplinkedin_login')); ?>">
        <?php echo csrf_field(); ?>
      <input type="submit" value="login with Linkedin">
    </form>
</html><?php /**PATH F:\MAGCOD\hrplatform-master\resources\views/login.blade.php ENDPATH**/ ?>