<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    


<div name="widget-holder">
    <script type="text/javascript" 
        src="https://www.linkedin.com/mjobs/awli/awliWidget">
    </script>
    <script type="IN/AwliWidget"  
        data-company-job-code="123d" 
        data-integration-context="urn:li:organization:1032984" 
        data-mode="BUTTON_DATA" 3
        data-callback-method="onProfileData" 
        data-api-key="775qwa0crhzm75"
        data-allow-sign-in="true">
    </script>
</div>




</body>
</html><?php /**PATH F:\MAGCOD\hrplatform-master\resources\views/linkedinapply.blade.php ENDPATH**/ ?>