<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div> 

     <h1><?php echo e($data->name); ?></h1>
     <h1><?php echo e($data->email); ?></h1>
     <h1><?php echo e($data->degree); ?></h1>
   <br>
     <img src="<?php echo e($data->avatar); ?>" alt="avatar" width="100" height="100">        
    </div>



    

    


    
   
</body>
</html><?php /**PATH F:\MAGCOD\hrplatform-master\resources\views/dashboard.blade.php ENDPATH**/ ?>